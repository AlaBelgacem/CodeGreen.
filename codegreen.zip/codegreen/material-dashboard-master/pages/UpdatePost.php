<?php
    require_once "../../php_mailer/mail.php";
    include_once '../Controller/PostController.php';
	$pc=new PostController();
	$membres=$pc->getuser($_GET["iduser"]);
	$to_email =$membres["mail"];
    $mail->setFrom('codegreen.or@gmail.com','codegreen');   // email eli bch tabath bih
    $mail->addAddress($membres["mail"]);   // email leli theb tabaathloo
    $mail->Subject = 'POSTS';
    $mail->Body='your post have been accepted by the admins thank you for your contribution';
    $mail->send();
	$pc->updateAdminPost($_GET["NumPost"]);
	header('Location:tables.php');
?>
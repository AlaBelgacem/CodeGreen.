<?php
    require_once "../../php_mailer/mail.php";
    include_once '../Controller/PostController.php';
	$pc=new PostController();
	$membres=$pc->getuser($_GET["iduser"]);
	$to_email =$membres["mail"];
    $mail->setFrom('codegreen.or@gmail.com','codegreen');   // email eli bch tabath bih
    $mail->addAddress($membres["mail"]);   // email leli theb tabaathloo
    $mail->Subject = 'POSTS';
    $mail->Body= 'sorry your post was denied thank you for your contribution';
    $mail->send();
	$pc->deletePost($_GET["NumPost"]);
	header('Location:tables.php');
?>
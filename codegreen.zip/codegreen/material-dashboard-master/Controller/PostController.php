<?php
	include '../config.php';
	include_once '../Models/Posts.php';
	class PostController {
		function showPosts(){
			$sql="SELECT  * FROM Posts where state=1";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMeesage());
			}
		}
		function showPost(){
			$sql="SELECT  * FROM Posts where state=0";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMeesage());
			}
		}
		
		function getuser($id){
			$sql="SELECT * from membres where id=$id";
			$db = config::getConnexion();
			try{
				$query=$db->prepare($sql);
				$query->execute();

				$Post=$query->fetch();
				return $Post;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}

		function getPost($id){
			$sql="SELECT * from Posts where id_post=$id";
			$db = config::getConnexion();
			try{
				$query=$db->prepare($sql);
				$query->execute();

				$Post=$query->fetch();
				return $Post;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}
		function showPostsinSlider(){
			$sql="SELECT  * FROM Posts LIMIT 3 ";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMeesage());
			}
		}
		function deletePost($NumPost){
			$sql="DELETE FROM Posts WHERE id_post=:id_post";
			$db = config::getConnexion();
			$req=$db->prepare($sql);
			$req->bindValue(':id_post', $NumPost);
			try{
				$req->execute();
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMeesage());
			}
		}
		function addPost($Post){
			$sql="INSERT INTO Posts (Title,Description,image,Content,datePost,id_user)
			VALUES (:Title,:Description,:image, :Content,:datePost,:id_user)";
			$db = config::getConnexion();
			$now = new DateTime();
			 $now->format('Y-m-d H:i:s');    // MySQL datetime format
			 
			try{
				$query = $db->prepare($sql);
				$query->execute([
					'Title' => $Post->getTitle(),
					'Description' => $Post->getDescription(),
					'image' => $Post->getimage(),
					'Content' => $Post->getContent(),
					'datePost' =>date("Y-m-d H:i:s"),
					'id_user'=>$Post->getid_user()
				]);			
			}
			catch (Exception $e){
				echo 'Erreur: '.$e->getMessage();
			}			
		}
		function addadminPost($Post){
			$sql="INSERT INTO Posts (Title,Description,image,Content,datePost,id_user,state)
			VALUES (:Title,:Description,:image,:Content,:datePost,:id_user,:state)";
			$db = config::getConnexion();
			$now = new DateTime();
			 $now->format('Y-m-d H:i:s');    // MySQL datetime format
			 
			try{
				$query = $db->prepare($sql);
				$query->execute([
					'Title' => $Post->getTitle(),
					'Description' => $Post->getDescription(),
					'image' => $Post->getimage(),
					'Content' => $Post->getContent(),
					'datePost' =>date("Y-m-d H:i:s"),
					'id_user'=>$Post->getid_user(),
					'state'=>$Post->getState()

				]);			
			}
			catch (Exception $e){
				echo 'Erreur: '.$e->getMessage();
			}			
		}

		function updateAdminPost($idpost){
			try {
				$db = config::getConnexion();
				$query = $db->prepare(
					'UPDATE Posts SET 
						state= :state 
					WHERE id_post= :id_post'
				);
				$query->execute([
					':state' => 1,
					':id_post' => $idpost
				]);
				echo $query->rowCount() . " records UPDATED successfully <br>";
			} catch (PDOException $e) {
				$e->getMessage();
			}
		}
		
		
		function updatePost($Post, $numPost){
			try {
				$db = config::getConnexion();
				$query = $db->prepare(
					'UPDATE Posts SET 
						Title= :Title, 
						Description= :Description, 
						image= :image, 
						Content= :Content 
					WHERE id_post= :id_post'
				);
				$query->execute([
					'Title' => $Post->getTitle(),
					'Description' => $Post->getDescription(),
					'image' => $Post->getimage(),
					'Content' => $Post->getContent(),
					'id_post' => $numPost
				]);
				echo $query->rowCount() . " records UPDATED successfully <br>";
			} catch (PDOException $e) {
				$e->getMessage();
			}
		}

	}
	class CommentsController {
		function showComments($idpost){
			$sql="SELECT  * FROM comments WHERE id_post=$idpost";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMeesage());
			}
		}
		function getClient($id){
			$sql="SELECT * from membres where id=$id";
			$db = config::getConnexion();
			try{
				$query=$db->prepare($sql);
				$query->execute();

				$client=$query->fetch();
				return $client;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}
		function getComments($id){
			$sql="SELECT * from comments where id_post=$id";
			$db = config::getConnexion();
			try{
				$query=$db->prepare($sql);
				$query->execute();

				$Comments=$query->fetch();
				return $Comments;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}
		function deleteComments($NumComments){
			//var_dump($NumComments);
			$sql="DELETE FROM comments WHERE id_Comment=$NumComments";
			var_dump($sql);
			$db = config::getConnexion();
			$req=$db->prepare($sql);
			//$req->bindValue(':id_Comments', $NumComments);
			try{
				$req->execute();
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMeesage());
			}
		}
		function addComments($idpost,$content){
			$sql="INSERT INTO comments(id_post,id_user,content,dateComment) VALUES (:id_post,:id_user,:content,:dateComment)";
			$db = config::getConnexion();
			$now = new DateTime();
			 $now->format('Y-m-d H:i:s');    // MySQL datetime format
			 
			try{
				$query = $db->prepare($sql);

				$query->bindValue(':id_post',$idpost);
				$query->bindValue(':id_user',1);
				$query->bindValue(':content',$content);
				$query->bindValue(':dateComment',date("Y-m-d H:i:s"));		
				$query->execute();
			}
			catch (Exception $e){
				echo 'Erreur: '.$e->getMessage();
			}			
		}
		function updateComments($idcom, $content){
			$sql="UPDATE comments SET content=:content,dateComment=:dateComment WHERE id_comment=$idcom";
			$db = config::getConnexion();
			$now = new DateTime();
			 $now->format('Y-m-d H:i:s');
			try{
				$query = $db->prepare($sql);
				$query->bindValue(':content',$content);
				$query->bindValue(':dateComment',date("Y-m-d H:i:s"));		
				$query->execute();
			}
			catch (PDOException $e) {
				$e->getMessage();
			}
		}
	}
?>
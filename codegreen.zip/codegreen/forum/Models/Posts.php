<?php
	class Posts{
		private $id_post=null;
		private $Title=null;
		private $Description=null;
		private $image=null;
		private $Content=null;
		private $datePost=null;
		private $id_user;
		
		function __construct($Title,$Description,$image,$Content,$id_user){
			$this->Title=$Title;
			$this->Description=$Description;
			$this->image=$image;
			$this->Content=$Content;
			$this->id_user=$id_user;
		}
		function getid_post(){
			return $this->id_post;
		}
		function getTitle(){
			return $this->Title;
		}
		function getDescription(){
			return $this->Description;
		}
		function getimage(){
			return $this->image;
		}
		function getContent(){
			return $this->Content;
		}
		function getid_user(){
			return $this->id_user;
		}
		function getdatePost(){
			return $this->datePost;
		}
		function setTitle(string $Title){
			$this->Title=$Title;
		}
		function setDescription(string $Description){
			$this->Description=$Description;
		}
		function setimage(string $image){
			$this->image=$image;
		}
		function setContent(string $Content){
			$this->Content=$Content;
		}
		function setid_user(string $id_user){
			$this->id_user=$id_user;
		}
		function setdatePost(string $datePost){
			$this->datePost=$datePost;
		}
	}

	class Comments{
		private $id_Comments=null;
		private $id_post=null;
		private $Content=null;
		private $dateComments=null;
		private $id_user;
		
		function __construct($Content,$id_user,$id_post,$dateComments){
			$this->Content=$Content;
			$this->id_post=$id_post;
			$this->id_user=$id_user;
			$this->dateComments=$dateComments;

		}
		function getid_Comments(){
			return $this->id_Comments;
		}
		function getContent(){
			return $this->Content;
		}
		function getid_user(){
			return $this->id_user;
		}
		function getdateComments(){
			return $this->dateComments;
		}
		function setContent(string $Content){
			$this->Content=$Content;
		}
		function getid_post(){
			return $this->dateComments;
		}
		function setid_post(string $id_post){
			$this->id_post=$id_post;
		}
		function setid_user(string $id_user){
			$this->id_user=$id_user;
		}
		function setdateComments(string $dateComments){
			$this->dateComments=$dateComments;
		}
	}

?>
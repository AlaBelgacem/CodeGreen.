<?php
    include_once '../../Controller/PostController.php';
	$pc=new PostController();

	$pc->deletePost($_GET["NumPost"]);
	header('Location:index.php');
?>
<?php
	include_once '../../Models/Posts.php';
    include_once '../../Controller/PostController.php';
    $pc=new PostController();
    echo $_GET["rate"];
	$pc->updaterating($_GET["rate"],$_GET["NumPost"]);
	header('Location:index.php');
?>
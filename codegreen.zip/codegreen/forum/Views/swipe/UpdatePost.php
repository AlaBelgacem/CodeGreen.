<?php
	include_once '../../Models/Posts.php';
    include_once '../../Controller/PostController.php';

    $error = "";

     // create post
     $post = null;

     // create an instance of the controller
     $postC = new PostController();
     if (
         isset($_POST["Title"]) &&
         isset($_POST["Description"]) &&		
         isset($_POST["image"]) &&
         isset($_POST["Content"])  
     ) {
         if (
             !empty($_POST["Title"]) && 
             !empty($_POST['Description']) &&
             !empty($_POST["image"]) && 
             !empty($_POST["Content"])  
         ) {
             $post = new Posts(
                 $_POST['Title'],
                 $_POST['Description'],
                 $_POST['image'], 
                 $_POST['Content'],
                 1
             );
            $postC->updatePost($post, $_POST["id_post"]);
            
             header('Location:index.php');
        }
        else
            $error = "Missing information";
    }    
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post Display</title>
    <?php
    include 'header.php'; 
    ?>
</head>
    <body>
        <br><br><br><br><br><br><br><br><br>
    <button><a href="index.php">Back to Posts</a></button>
        <hr>
        
        <div id="error">
            <?php echo $error; ?>
        </div>
			
		<?php
			if (isset($_POST['id_post'])){
				$post = $postC->getPost($_POST['id_post']);
				
		?>
        
        <form action="" method="POST">
            <table border="1" align="center">
                <tr>
                    <td>
                        <label for="id_post">Post Number:
                        </label>
                    </td>
                    <td><input type="text" name="id_post" id="id_post" value="<?php echo $post['id_post']; ?>" maxlength="20"></td>
                </tr>
                <tr>
                    <td>
                        <label for="Title">Post Title:
                        </label>
                    </td>
                    <td><input type="text" name="Title" id="Title" maxlength="20" value="<?php echo $post['Title']; ?>"></td>
                </tr>
				<tr>
                    <td>
                        <label for="Description">Description:
                        </label>
                    </td>
                    <td>
                        <textarea name="Description" id="Description" cols="30" rows="10" ><?php echo $post['Description']; ?></textarea>
                        </td>
                </tr>
                <tr>
                    <td>
                        <label for="image">image:
                        </label>
                    </td>
                    <td><input type="file" name="image" id="image" maxlength="20" value="<?php echo $post['image']; ?>"></td>
                </tr>
                <tr>
                    <td>
                        <label for="Content">Content:
                        </label>
                    </td>
                    <td>
                        <textarea name="Content" id="Content" cols="30" rows="10" placeholder=""><?php echo $post['Content']; ?></textarea>
                    </td>
                </tr>            
                <tr>
                    <td></td>
                    <td>
                        <input type="submit" value="Modify"> 
                    </td>
                    <td>
                        <input type="reset" value="Cancel" >
                    </td>
                </tr>
            </table>
        </form>
		<?php
		}
		?>
    </body>
</html>
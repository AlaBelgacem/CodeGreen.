<?php

  include_once '../../Controller/PostController.php';
	$pc=new PostController();
	$PostsLimited=$pc->showPostsinSlider();
  $sort=$_GET["sort"];
  if($sort==NULL){
    $Posts=$pc->showPosts();
  }
  else {
    $Posts=$pc->showPost($sort);
  }
  include 'header.php';
?>

<body>
  <br><br>


  <div class="blog-slider">
    <div class="blog-slider__wrp swiper-wrapper">
      <?php foreach($PostsLimited as $post){?>
        <div class="blog-slider__item swiper-slide">
            <div class="blog-slider__img">
              <?php echo ' <img src="../img/'.$post['image'].'" alt="">'; ?>
              </div>
                <div class="blog-slider__content">
                  <span class="blog-slider__code"><?php echo $post['datePost']; ?></span>
                  <span class="blog-slider__title"><?php echo $post['Title']; ?></span>
                  <div class="blog-slider__text"><?php echo $post['Description']; ?>
                    </div>
                    <a href="../article\posts.php?NumPost=<?php echo $post['id_post']; ?>" class="blog-slider__button">READ MORE</a>
                </div>
        </div>
      <?php }?>
    </div>
    <div class="blog-slider__pagination"></div>
    <a href="AddPost.php" class="blog-slider__button">Add Post</a>
  </div>

  <div class="container mt-5 mb-5">
        <input id="searchbar" onkeyup="search_animal()" type="text" name="search" placeholder="Search...">
        <br>
        <label for="none">sort by</label>
        <a href="index.php?sort=" name="none">none</a>
        <a href="index.php?sort=datePost" name="date">date</a>
        <a href="index.php?sort=Title" name="title">title</a>
        <a href="index.php?sort=rating" name="rating">rating</a>
    <div class="d-flex justify-content-center row">
      <div class="col-md-10">
        <?php foreach($Posts as $post){?>
          <div class="row p-2 border rounded">
              <div class="col-md-3 mt-1"><img class=" product-image" src="../img/<?php echo $post['image']; ?>">
                </div>
              <div class="col-md-6 mt-1">
                  <h5><?php echo $post['Title']; ?></h5>
                    <div class="mt-1 mb-1 spec-1">
                        <span><?php echo $post['datePost']; ?></span>
                          </div>
                      <p ><?php echo $post['Description']; ?><br><br></p>
                      <p><?php echo $post['rating']; ?> likes</p>
                      <a href="updaterating.php?NumPost=<?php echo $post['id_post']; ?>&rate=<?php echo $post['rating']; ?>" class="blog-slider__button">like</a>
                      <a href="../article\posts.php?NumPost=<?php echo $post['id_post']; ?>" class="blog-slider__button">READ MORE</a>
                      <a href="DeletePost.php?NumPost=<?php echo $post['id_post']; ?>" class="blog-slider__button">Delete Post</a>
                      <form method="POST" action="UpdatePost.php">
                        <input type="submit" name="Modifier" value="Update" class="blog-slider__button">
                        <input type="hidden" value=<?PHP echo $post['id_post']; ?> name="id_post">
                      </form>
              </div>
          </div>
        <?php } ?>
      </div>  
    </div>
  </div>
  <?php
    include '../footer.php';
  ?>

  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/js/swiper.min.js'></script>
  <script  src="./script.js"></script>
  <script  src="search.js"></script>
  
</body>


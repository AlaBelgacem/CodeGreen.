<?php 
	include 'header.php';
    include_once '../../Controller/PostController.php';
    include_once '../../Models/Posts.php';
    $id=$_GET['NumPost'];   
    $pc=new PostController();
    $post=$pc->getPost($id);
    $cm=new CommentsController();
    $comment=$cm->showComments($id);

?>
<body>
    <div class="article">
        <h1><?php echo $post['Title']; ?></h1>
        <img src="../img/<?php echo $post['image']; ?>" alt="">
        <p><?php echo $post['Content']; ?></p>
        <h2>comment section</h2>
        <?php 
        foreach($comment as $com){
            $client=$cm->getClient($com['id_user']);
        ?>
        <br><img src="C:\Riot Games\Riot Client\Resources\icon.ico" alt="" name="image" id="image">
        <label for="image"><?php echo $client['First_Name']; echo " ".$client['Last_Name'];?></label>
        <p><?php echo $com['content'];?></p>
        <div id='buttons'>
  <button id="show">Modify</button>
  <button id='hide'>X</button>
</div>
  <form id='f' method="POST" action="UpdateComment.php">
    <textarea name='textarea' id='textarea' style="display:none"></textarea>
    <input type="hidden" name="idcom" id="idcom" value="<?php echo $com['id_comment'];?>">
    <input type="hidden" name="idpost" id="idpost" value="<?php echo $id?>">
    <input type="submit" value="Send" id="send" style="display:none">
  </form>

        <button><a href="DeleteComment.php?NumCom=<?php echo $com['id_comment'] ?>&idpost=<?php echo $id?>">Delete</a></button>
        <?php }?>
        <form id="s" name="s" action="AddComment.php" method='POST'>
            <div class="comment">
                <div class="com">
                    <img class="img" src="C:\Riot Games\Riot Client\Resources\icon.ico" alt="">
                    <textarea name="Cont" id="Cont" cols="50" rows="3"></textarea>
                    <input type="submit" value="comment">
                    <input type="hidden" name="idpost" id='idpost' value='<?php echo $post['id_post'];?>'>
                </div>
        </div>
    </form>
        
        
    </div>
    <?php
    include '../footer.php';
  ?>
    <script src="dropdowns.js"></script>
</body>
</html>
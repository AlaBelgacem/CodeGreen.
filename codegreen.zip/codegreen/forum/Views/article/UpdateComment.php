<?php
    include_once '../../Controller/PostController.php';
	$pc=new CommentsController();
	$pc->updateComments($_POST["idcom"],$_POST['textarea']);
	header('Location:posts.php?NumPost='.$_POST["idpost"]);
?>
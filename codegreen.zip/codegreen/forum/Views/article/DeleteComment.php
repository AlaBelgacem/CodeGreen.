<?php
    include_once '../../Controller/PostController.php';
	$pc=new CommentsController();
	$pc->deleteComments($_GET["NumCom"]);
	header('Location:posts.php?NumPost='.$_GET['idpost'] );
?>
var show = document.getElementById('show');
var hide = document.getElementById('hide');
var form = document.getElementById('f');
var textarea = document.getElementById('textarea');
var send = document.getElementById('send');

show.addEventListener('click', function(){
  form.style = ('display: flex');
  textarea.style = ('animation: riseHeight 1s .1s normal forwards');
  hide.style = ('display: flex');
  send.style = ('display: flex');
  show.disabled = true;
})

hide.addEventListener('click', function() {
  form.style = ('display: none');
  hide.style = ('display: none');
  send.style = ('display: none');
  show.disabled = false;
})

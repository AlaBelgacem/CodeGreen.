<?php
    include_once '../../Controller/PostController.php';
	$pc=new CommentsController();
	if(!empty($_POST['Cont'])){
		$pc->addComments($_POST["idpost"],$_POST['Cont']);
	}
	header('Location:posts.php?NumPost='.$_POST["idpost"]);
?>